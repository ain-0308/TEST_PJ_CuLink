import json
import gzip
from datetime import datetime

def prepare_combined_data(conv_metadata: list, report_data: dict, en_report_images: list):
    """메타데이터, 레포트, 이미지를 결합하여 딕셔너리 생성"""
    return {
        'metadata' : conv_metadata,
        'report_titles':report_data['titles'],
        'report_data' : report_data["reports"],
        'report_images' : en_report_images,
        'created_at': datetime.now().isoformat(),
    }

def compress_data(data: dict):
    """JSON 데이터 직렬화 및 압축"""
    json_text = json.dumps(data).encode('utf-8')
    return gzip.compress(json_text)