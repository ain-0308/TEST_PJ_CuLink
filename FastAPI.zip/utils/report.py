from models.report_openai import createReport_openAI

def generate_report(article_contents: list):
    """레포트 생성 모델을 호출"""
    return createReport_openAI(article_contents)