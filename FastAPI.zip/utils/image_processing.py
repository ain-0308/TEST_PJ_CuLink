import base64
from models.textToImage import generate_images_and_send


def encode_images(report_images):
    encoded_images = []
    for image in report_images:
        try:
            encoded_image = {
                "file_name" : image["file_name"],
                "style" : image["style"],
                "image_data" : base64.b64encode(image["image_data"]).decode('utf-8')
            }
            encoded_images.append(encoded_image)
        except  KeyError as e:
            print(f"이미지 인코딩 키에러 {e}")
    return encoded_images

def process_images(text: str):
    """이미지 생성 및 바이너리 처리"""
    images = generate_images_and_send(text)
    return encode_images(images)
