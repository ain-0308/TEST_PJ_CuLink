from db.db_config import get_db_connection
from utils.mysql_querys import query_metadata_from_db
from datetime import datetime
from db.settings import *
# datetime 변환 함수
def convert_datetime_in_metadata(metadata):
    for item in metadata:
        if isinstance(item.get('cr_art_date'), datetime):
            item['cr_art_date'] = item['cr_art_date'].isoformat()  # datetime을 문자열로 변환
    return metadata

def fetch_metadata(id_list: list):
    """데이터베이스에서 메타데이터를 조회하고 datetime 변환"""
    connection = get_db_connection(database_config)
    metadata = query_metadata_from_db(id_list, connection)
    return convert_datetime_in_metadata(metadata)