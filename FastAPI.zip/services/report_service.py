from db.settings import *
# 사용할 함수 불러오기
from utils.firebase_utils import fetch_article_content
from utils.image_processing import process_images
from utils.data_processing import prepare_combined_data, compress_data
from db.firebase_config import bucket
from utils.database import *
from utils.report import generate_report




def createReport_services(id_list: list):
    try:
        metadata = fetch_metadata(id_list)
        # datetime을 문자열로 변환
        conv_metadata = convert_datetime_in_metadata(metadata)
        # Firebase 원문 조회
        article_contents = fetch_article_content(id_list,bucket)
        # 레포트 생성 모델 결과 값
        report_data = generate_report(article_contents)
        # 이미지 생성 및 처리
        report_images = process_images(report_data["img_txt"])
        # 데이터 결합 및 직렬화
        combined_data  = prepare_combined_data(conv_metadata, report_data, report_images)
        # 데이터 압축
        comprs_data = compress_data(combined_data)
    except Exception as e:
        print("combined_data 압축 에러:", e)
    
    return comprs_data

